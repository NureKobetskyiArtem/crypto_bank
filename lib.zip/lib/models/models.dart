// lib/models/models.dart

// ── User ──────────────────────────────────────────────────────────────────────

class UserProfile {
  final String id;
  final String email;
  final String displayName;
  final DateTime createdAt;

  UserProfile({
    required this.id,
    required this.email,
    required this.displayName,
    required this.createdAt,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'email': email,
        'displayName': displayName,
        'createdAt': createdAt.toIso8601String(),
      };

  factory UserProfile.fromJson(Map<String, dynamic> json) => UserProfile(
        id: json['id'],
        email: json['email'],
        displayName: json['displayName'],
        createdAt: DateTime.parse(json['createdAt']),
      );
}

// ── Enums ─────────────────────────────────────────────────────────────────────

enum TransactionType {
  cryptoReceived,
  cryptoSent,
  cryptoToFiat,     // крипто → EUR или USD
  fiatToCrypto,     // EUR/USD → крипто
  cardPayment,      // перевод с EUR-карты
  cardPaymentUsd,   // перевод с USD-карты
  cryptoSwap,       // USDT ↔ USDC
  cardTopup,
}

enum CryptoAsset { usdt, usdc }

extension CryptoAssetExt on CryptoAsset {
  String get symbol => name.toUpperCase();
  String get network => this == CryptoAsset.usdt ? 'TRC-20' : 'Polygon';
  String get fullName =>
      this == CryptoAsset.usdt ? 'Tether USD' : 'USD Coin';
  String get coingeckoId =>
      this == CryptoAsset.usdt ? 'tether' : 'usd-coin';
}

// Валюта фиатной карты
enum FiatCurrency { eur, usd }

extension FiatCurrencyExt on FiatCurrency {
  String get code => name.toUpperCase();
  String get symbol => this == FiatCurrency.eur ? '€' : '\$';
  String get label => this == FiatCurrency.eur ? 'Euro' : 'US Dollar';
}

// ── Transaction ───────────────────────────────────────────────────────────────

class Transaction {
  final String id;
  final TransactionType type;
  final double amount;
  final String currency;       // исходная валюта
  final DateTime date;
  final String description;
  final double? secondAmount;
  final String? secondCurrency;
  // Card payments
  final String? recipientCard;
  final String? recipientName;
  final String? note;
  // Crypto swap
  final String? swapFromAsset;
  final String? swapToAsset;
  // Какой карте принадлежит транзакция
  final String? cardCurrency; // 'EUR' или 'USD'

  Transaction({
    required this.id,
    required this.type,
    required this.amount,
    required this.currency,
    required this.date,
    required this.description,
    this.secondAmount,
    this.secondCurrency,
    this.recipientCard,
    this.recipientName,
    this.note,
    this.swapFromAsset,
    this.swapToAsset,
    this.cardCurrency,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type.index,
        'amount': amount,
        'currency': currency,
        'date': date.toIso8601String(),
        'description': description,
        'secondAmount': secondAmount,
        'secondCurrency': secondCurrency,
        'recipientCard': recipientCard,
        'recipientName': recipientName,
        'note': note,
        'swapFromAsset': swapFromAsset,
        'swapToAsset': swapToAsset,
        'cardCurrency': cardCurrency,
      };

  factory Transaction.fromJson(Map<String, dynamic> json) => Transaction(
        id: json['id'],
        type: TransactionType.values[json['type']],
        amount: (json['amount'] as num).toDouble(),
        currency: json['currency'],
        date: DateTime.parse(json['date']),
        description: json['description'],
        secondAmount: json['secondAmount'] != null
            ? (json['secondAmount'] as num).toDouble()
            : null,
        secondCurrency: json['secondCurrency'],
        recipientCard: json['recipientCard'],
        recipientName: json['recipientName'],
        note: json['note'],
        swapFromAsset: json['swapFromAsset'],
        swapToAsset: json['swapToAsset'],
        cardCurrency: json['cardCurrency'],
      );
}

// ── Virtual Card ──────────────────────────────────────────────────────────────

class VirtualCard {
  final String number;
  final String holderName;
  final String expiry;
  final String cvv;
  final bool isActive;
  final String currency; // 'EUR' or 'USD'

  VirtualCard({
    required this.number,
    required this.holderName,
    required this.expiry,
    required this.cvv,
    this.isActive = true,
    this.currency = 'EUR',
  });

  String get maskedNumber {
    final digits = number.replaceAll(' ', '');
    return '**** **** **** ${digits.substring(digits.length - 4)}';
  }

  Map<String, dynamic> toJson() => {
        'number': number,
        'holderName': holderName,
        'expiry': expiry,
        'cvv': cvv,
        'isActive': isActive,
        'currency': currency,
      };

  factory VirtualCard.fromJson(Map<String, dynamic> json) => VirtualCard(
        number: json['number'],
        holderName: json['holderName'],
        expiry: json['expiry'],
        cvv: json['cvv'],
        isActive: json['isActive'] ?? true,
        currency: json['currency'] ?? 'EUR',
      );
}

// ── Exchange Rates ────────────────────────────────────────────────────────────

class ExchangeRates {
  final double usdtToUsd;
  final double usdcToUsd;
  final double usdToEur;
  final double usdToGbp;
  final double usdToUah;
  final double btcToUsd;
  final double ethToUsd;
  final DateTime updatedAt;

  ExchangeRates({
    required this.usdtToUsd,
    required this.usdcToUsd,
    required this.usdToEur,
    required this.usdToGbp,
    required this.usdToUah,
    required this.btcToUsd,
    required this.ethToUsd,
    required this.updatedAt,
  });

  double get usdtToEur => usdtToUsd * usdToEur;
  double get usdcToEur => usdcToUsd * usdToEur;
  double get usdToEurRate => usdToEur;

  static ExchangeRates fallback() => ExchangeRates(
        usdtToUsd: 1.0,
        usdcToUsd: 1.0,
        usdToEur: 0.92,
        usdToGbp: 0.79,
        usdToUah: 41.5,
        btcToUsd: 105000,
        ethToUsd: 2500,
        updatedAt: DateTime.now(),
      );
}
