// lib/providers/auth_provider.dart
//
// Локальная авторизация на SharedPreferences + SHA-256 хэш пароля.
// Для курсового проекта — полноценная имитация auth flow.

import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/models.dart';

enum AuthStatus { unknown, guest, authenticated }

class AuthProvider extends ChangeNotifier {
  AuthStatus _status = AuthStatus.unknown;
  UserProfile? _user;
  String? _error;
  bool _isLoading = false;

  AuthStatus get status => _status;
  UserProfile? get user => _user;
  String? get error => _error;
  bool get isLoading => _isLoading;
  bool get isAuthenticated => _status == AuthStatus.authenticated;
  bool get isGuest => _status == AuthStatus.guest || _status == AuthStatus.unknown;

  AuthProvider() {
    _restoreSession();
  }

  // ── Session restore ───────────────────────────────────────────────────────

  Future<void> _restoreSession() async {
    final prefs = await SharedPreferences.getInstance();
    final userJson = prefs.getString('auth_user');
    if (userJson != null) {
      try {
        _user = UserProfile.fromJson(jsonDecode(userJson));
        _status = AuthStatus.authenticated;
      } catch (_) {
        _status = AuthStatus.guest;
      }
    } else {
      _status = AuthStatus.guest;
    }
    notifyListeners();
  }

  // ── Register ──────────────────────────────────────────────────────────────

  Future<String?> register({
    required String email,
    required String password,
    required String displayName,
  }) async {
    _setLoading(true);

    final emailTrimmed = email.trim().toLowerCase();
    final nameTrimmed = displayName.trim();

    // Validations
    if (!_isValidEmail(emailTrimmed)) {
      _setLoading(false);
      return 'Enter a valid email address';
    }
    if (password.length < 6) {
      _setLoading(false);
      return 'Password must be at least 6 characters';
    }
    if (nameTrimmed.isEmpty) {
      _setLoading(false);
      return 'Enter your name';
    }

    final prefs = await SharedPreferences.getInstance();

    // Check if email already registered
    final existingRaw = prefs.getString('accounts');
    final Map<String, dynamic> accounts =
        existingRaw != null ? jsonDecode(existingRaw) : {};

    if (accounts.containsKey(emailTrimmed)) {
      _setLoading(false);
      return 'This email is already registered';
    }

    // Store account
    final userId = _generateId();
    final passwordHash = _hashPassword(password);

    accounts[emailTrimmed] = {
      'id': userId,
      'passwordHash': passwordHash,
      'displayName': nameTrimmed,
      'createdAt': DateTime.now().toIso8601String(),
    };

    await prefs.setString('accounts', jsonEncode(accounts));

    // Create user session
    final profile = UserProfile(
      id: userId,
      email: emailTrimmed,
      displayName: nameTrimmed,
      createdAt: DateTime.now(),
    );
    await _saveSession(prefs, profile);

    _user = profile;
    _status = AuthStatus.authenticated;
    _setLoading(false);
    return null; // success
  }

  // ── Login ─────────────────────────────────────────────────────────────────

  Future<String?> login({
    required String email,
    required String password,
  }) async {
    _setLoading(true);

    final emailTrimmed = email.trim().toLowerCase();

    if (!_isValidEmail(emailTrimmed)) {
      _setLoading(false);
      return 'Enter a valid email address';
    }
    if (password.isEmpty) {
      _setLoading(false);
      return 'Enter your password';
    }

    final prefs = await SharedPreferences.getInstance();
    final existingRaw = prefs.getString('accounts');
    if (existingRaw == null) {
      _setLoading(false);
      return 'No account found. Please register first';
    }

    final Map<String, dynamic> accounts = jsonDecode(existingRaw);
    if (!accounts.containsKey(emailTrimmed)) {
      _setLoading(false);
      return 'No account found with this email';
    }

    final account = accounts[emailTrimmed] as Map<String, dynamic>;
    final storedHash = account['passwordHash'] as String;

    if (storedHash != _hashPassword(password)) {
      _setLoading(false);
      return 'Incorrect password';
    }

    final profile = UserProfile(
      id: account['id'],
      email: emailTrimmed,
      displayName: account['displayName'],
      createdAt: DateTime.parse(account['createdAt']),
    );

    await _saveSession(prefs, profile);
    _user = profile;
    _status = AuthStatus.authenticated;
    _setLoading(false);
    return null; // success
  }

  // ── Logout ────────────────────────────────────────────────────────────────

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_user');
    _user = null;
    _status = AuthStatus.guest;
    notifyListeners();
  }

  // ── Update profile name ───────────────────────────────────────────────────

  Future<String?> updateDisplayName(String newName) async {
    if (_user == null) return 'Not authenticated';
    final trimmed = newName.trim();
    if (trimmed.isEmpty) return 'Name cannot be empty';

    final prefs = await SharedPreferences.getInstance();

    // Update accounts store
    final existingRaw = prefs.getString('accounts');
    if (existingRaw != null) {
      final Map<String, dynamic> accounts = jsonDecode(existingRaw);
      if (accounts.containsKey(_user!.email)) {
        accounts[_user!.email]['displayName'] = trimmed;
        await prefs.setString('accounts', jsonEncode(accounts));
      }
    }

    // Update session
    final updated = UserProfile(
      id: _user!.id,
      email: _user!.email,
      displayName: trimmed,
      createdAt: _user!.createdAt,
    );
    await _saveSession(prefs, updated);
    _user = updated;
    notifyListeners();
    return null;
  }

  // ── Change password ───────────────────────────────────────────────────────

  Future<String?> changePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    if (_user == null) return 'Not authenticated';
    if (newPassword.length < 6) return 'New password must be at least 6 characters';

    final prefs = await SharedPreferences.getInstance();
    final existingRaw = prefs.getString('accounts');
    if (existingRaw == null) return 'Account data not found';

    final Map<String, dynamic> accounts = jsonDecode(existingRaw);
    final account = accounts[_user!.email] as Map<String, dynamic>?;
    if (account == null) return 'Account not found';

    if (account['passwordHash'] != _hashPassword(currentPassword)) {
      return 'Current password is incorrect';
    }

    account['passwordHash'] = _hashPassword(newPassword);
    await prefs.setString('accounts', jsonEncode(accounts));
    return null;
  }

  // ── Helpers ───────────────────────────────────────────────────────────────

  Future<void> _saveSession(SharedPreferences prefs, UserProfile profile) async {
    await prefs.setString('auth_user', jsonEncode(profile.toJson()));
  }

  String _hashPassword(String password) {
    final bytes = utf8.encode(password + 'cryptobank_salt_2024');
    return sha256.convert(bytes).toString();
  }

  bool _isValidEmail(String email) {
    return RegExp(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
        .hasMatch(email);
  }

  String _generateId() {
    final now = DateTime.now().millisecondsSinceEpoch.toString();
    final bytes = utf8.encode(now);
    return sha256.convert(bytes).toString().substring(0, 16);
  }

  void _setLoading(bool val) {
    _isLoading = val;
    _error = null;
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}
